package com.empresa.AutoresFeign;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AutoresFeignApplicationTests {

	@Test
	void contextLoads() {
	}

}
