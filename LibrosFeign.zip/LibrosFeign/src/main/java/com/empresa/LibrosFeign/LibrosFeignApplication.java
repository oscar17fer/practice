package com.empresa.LibrosFeign;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LibrosFeignApplication {

	public static void main(String[] args) {
		SpringApplication.run(LibrosFeignApplication.class, args);
	}

}
